package com.example.onlinepharmacystore;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class BillItemArrayAdapter extends RecyclerView.Adapter<BillItemArrayAdapter.ViewHolder> {
    public ArrayList<Order> itemArrayList;

    public BillItemArrayAdapter(ArrayList<Order> itemArrayList){
        this.itemArrayList = itemArrayList;
    }


    // Joining the bill layout with the recycler view

    @NonNull
    @Override
    public BillItemArrayAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.bill_item_layout, parent, false);
        BillItemArrayAdapter.ViewHolder viewHolder = new BillItemArrayAdapter.ViewHolder(view);
        return viewHolder;
    }

    //Binding each row of the layout to a given data from the firebase
    @Override
    public void onBindViewHolder(@NonNull BillItemArrayAdapter.ViewHolder holder, final int position) {
        holder.txt_productName.setText(itemArrayList.get(position).ProductName);
        holder.txt_productPrice.setText(String.valueOf(itemArrayList.get(position).ProductPrice));
        holder.txt_requiredQty.setText(String.valueOf(itemArrayList.get(position).RequiredQty));
        holder.txt_total.setText(String.valueOf(itemArrayList.get(position).Total));
    }

    @Override
    public int getItemCount() {
        if(itemArrayList == null)
            return 0;
        else
            return itemArrayList.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        ImageView productImage;

        TextView txt_productName, txt_productPrice, txt_requiredQty, txt_total;

        public ViewHolder(@NonNull final View itemView) {
            super(itemView);
            productImage = itemView.findViewById(R.id.imageView);

            txt_productName = itemView.findViewById(R.id.textView21);
            txt_productPrice = itemView.findViewById(R.id.textView18);
            txt_requiredQty = itemView.findViewById(R.id.textView19);
            txt_total = itemView.findViewById(R.id.textView20);

        }
    }

}
