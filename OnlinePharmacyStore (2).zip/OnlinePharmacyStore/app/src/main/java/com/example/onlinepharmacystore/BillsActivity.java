package com.example.onlinepharmacystore;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class BillsActivity extends AppCompatActivity {

    RecyclerView data;
    ArrayList<Order> arrayList;
    BillItemArrayAdapter cartAdapter;
    RatingBar ratingBar;

    FirebaseDatabase fb;
    DatabaseReference myDB, myRating;

    Button goBack;
    TextView customerName, invoiceNumber, date, paid, total, ratingReview;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bills);

        customerName = findViewById(R.id.textView34);
        invoiceNumber = findViewById(R.id.textView36);
        date = findViewById(R.id.textView38);
        paid = findViewById(R.id.textView47);
        total = findViewById(R.id.textView50);

        //Get the current date with a specific format
        SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yyyy");
        String currentDate = sdf.format(new Date());

        customerName.setText(GlobalData.userName);
        paid.setText(String.valueOf(GlobalData.paid));
        invoiceNumber.setText(String.valueOf(GlobalData.getInvoiceNO()));
        total.setText(String.valueOf(GlobalData.paid));
        date.setText(currentDate);

        data = findViewById(R.id.recyclerView2);
        arrayList = new ArrayList<Order>();

        fb = FirebaseDatabase.getInstance();

        myDB = fb.getReference("orders");

        //this one for saving the rating on a separated array
        myRating = fb.getReference("ratings");


        goBack = findViewById(R.id.button10);

        ratingBar = findViewById(R.id.ratingBar);
        ratingReview = findViewById(R.id.textView9);

        //rating listener and gives its values
        ratingBar.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
            @Override
            public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {
                if(rating == 1){
                    ratingReview.setText("Poor");
                }
                else if(rating == 2){
                    ratingReview.setText("Farly Good");
                }
                else if(rating == 3){
                    ratingReview.setText("Good");
                }
                else if(rating == 4){
                    ratingReview.setText("Best");
                }
                else if(rating == 5){
                    ratingReview.setText("Excellent");
                }
            }
        });

        // go back button that will check first the user did give any rate
        goBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(ratingReview.getText().toString().equals("rate")){
                    Intent i = new Intent(BillsActivity.this, ProductsActivity.class);
                    startActivity(i);
                }
                else{
                    RatingInfo ratingInfo = new RatingInfo(GlobalData.userName, ratingReview.getText().toString());
                    String key = myRating.push().getKey();
                    myRating.child(key).setValue(ratingInfo);
                    Toast.makeText(BillsActivity.this, "Thanks for your rating!", Toast.LENGTH_SHORT).show();
                    Intent i = new Intent(BillsActivity.this, ProductsActivity.class);
                    startActivity(i);
                }

            }
        });

        //binding the data from orders to the bill to view
        myDB.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for(DataSnapshot ds : snapshot.getChildren()){
                    Order order = ds.getValue(Order.class);
                    if(order.UserName.equals(GlobalData.userName)){
                        arrayList.add(new Order(order.OrderID, order.ProductID, order.RequiredQty, order.ProductPrice, order.ProductName, order.Total, order.UserName));
                    }
                }
                cartAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        data.setLayoutManager(linearLayoutManager);
        cartAdapter = new BillItemArrayAdapter(arrayList);
        data.setAdapter(cartAdapter);
    }
}