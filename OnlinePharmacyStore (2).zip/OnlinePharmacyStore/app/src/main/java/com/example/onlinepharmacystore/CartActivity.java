package com.example.onlinepharmacystore;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class CartActivity extends AppCompatActivity {

    RecyclerView data;
    ArrayList<Order> arrayList;
    CartItemArrayAdapter cartAdapter;

    Button goBack, checkout;

    FirebaseDatabase fb;
    DatabaseReference myDB;

    TextView totalPrice;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cart);

        data = findViewById(R.id.recyclerView3);
        arrayList = new ArrayList<Order>();

        totalPrice = findViewById(R.id.textView23);

        goBack = findViewById(R.id.button8);
        checkout = findViewById(R.id.button7);

        //Go back button
        goBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(CartActivity.this, ProductsActivity.class);
                startActivity(i);
            }
        });

        //Proceed to checkout if the customer did order some items
        checkout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(GlobalData.totalPrice == 0.0){
                    Toast.makeText(CartActivity.this, "You need to add items to your cart to proceed", Toast.LENGTH_SHORT).show();
                }
                else {
                    Intent i = new Intent(CartActivity.this, PaymentActivity.class);
                    startActivity(i);
                }
            }
        });

        totalPrice.setText(String.valueOf(GlobalData.totalPrice));


        fb = FirebaseDatabase.getInstance();
        myDB = fb.getReference("orders");

        myDB.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for(DataSnapshot ds : snapshot.getChildren()){
                    Order order = ds.getValue(Order.class);
                    if(order.UserName.equals(GlobalData.userName)){
                        arrayList.add(new Order(order.OrderID, order.ProductID, order.RequiredQty, order.ProductPrice, order.ProductName, order.Total, order.UserName));
                    }
                }
                cartAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

            LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
            data.setLayoutManager(linearLayoutManager);
            cartAdapter = new CartItemArrayAdapter(arrayList);
            data.setAdapter(cartAdapter);
    }
}