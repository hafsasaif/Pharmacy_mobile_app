package com.example.onlinepharmacystore;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.Objects;

public class CartItemArrayAdapter extends RecyclerView.Adapter<CartItemArrayAdapter.ViewHolder> {
    public ArrayList<Order> itemArrayList;

    public CartItemArrayAdapter(ArrayList<Order> itemArrayList){
        this.itemArrayList = itemArrayList;
    }


    // Joining the layout with the recycler view
    @NonNull
    @Override
    public CartItemArrayAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.cart_item_layout, parent, false);
        CartItemArrayAdapter.ViewHolder viewHolder = new CartItemArrayAdapter.ViewHolder(view);
        return viewHolder;
    }

    // binging the date from the arrayList
    @Override
    public void onBindViewHolder(@NonNull CartItemArrayAdapter.ViewHolder holder, final int position) {
        holder.txt_productName.setText(itemArrayList.get(position).ProductName);
        holder.txt_productPrice.setText(String.valueOf(itemArrayList.get(position).ProductPrice));
        holder.txt_requiredQty.setText(String.valueOf(itemArrayList.get(position).RequiredQty));
        holder.txt_total.setText(String.valueOf(itemArrayList.get(position).Total));

        //Remove any item from the cart
        holder.remove.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(final View v) {
                FirebaseDatabase fb;
                DatabaseReference myDB;
                fb = FirebaseDatabase.getInstance();
                myDB = fb.getReference("orders");
                Query query = myDB.orderByChild("OrderID").equalTo(itemArrayList.get(position).OrderID);
                query.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        for(DataSnapshot ds : snapshot.getChildren()){
                            ds.getRef().removeValue();
                            Toast.makeText(v.getContext(), "Deleted from cart", Toast.LENGTH_SHORT).show();

                            if(GlobalData.totalPrice != 0){
                                GlobalData.totalPrice = GlobalData.totalPrice - itemArrayList.get(position).Total;
                                itemArrayList.remove(position);
                                notifyItemRemoved(position);
                                notifyItemRangeChanged(position, itemArrayList.size());
                            }
                            break;
                        }
                    }
                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });

            }

        });
    }

    @Override
    public int getItemCount() {
        if(itemArrayList == null)
            return 0;
        else
            return itemArrayList.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        ImageView productImage, remove;

        TextView txt_productName, txt_productPrice, txt_requiredQty, txt_total, txt_totalPrice;

        public ViewHolder(@NonNull final View itemView) {
            super(itemView);
            productImage = itemView.findViewById(R.id.imageView);
            txt_productName = itemView.findViewById(R.id.textView21);
            txt_productPrice = itemView.findViewById(R.id.textView18);
            txt_requiredQty = itemView.findViewById(R.id.textView19);
            txt_total = itemView.findViewById(R.id.textView20);

            txt_totalPrice = itemView.findViewById(R.id.textView23);
            remove = itemView.findViewById(R.id.imageView4);

//            remove.setOnClickListener(new View.OnClickListener() {
//                @Override
//                public void onClick(View v) {
//                    txt_totalPrice.setText(String.valueOf(GlobalData.totalPrice));
//                }
//            });

        }
    }
}
