package com.example.onlinepharmacystore;

import java.util.Random;

public class GlobalData {
    public static String userName;
    public static double totalPrice = 0.0;
    public static double paid = 0.0;
    public static int invoiceNO = 0;


    public static int getInvoiceNO() {
        Random random = new Random();
        int randomNumber = random.nextInt(10000000);
        return invoiceNO + randomNumber;
    }
}
