package com.example.onlinepharmacystore;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MainActivity extends AppCompatActivity {

    EditText email, password;
    Button login, newUser;

    FirebaseDatabase fb;
    DatabaseReference myDB;
    int flag = 0;

    public String UserEmail;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Edit Text References
        email = findViewById(R.id.editTextTextPersonName7);
        password = findViewById(R.id.editTextTextPersonName8);

        //Button References
        login = findViewById(R.id.button3);
        newUser = findViewById(R.id.button4);

        //Firebase
        fb = FirebaseDatabase.getInstance();
        myDB = fb.getReference("users");

        //Email Validation
        final String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";

        //Login Function
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(email.getText().toString().isEmpty()){
                    email.setError("Email is required");
                }
                else if(!email.getText().toString().trim().matches(emailPattern)){
                    email.setError("Invalid email address");
                }
                else if(password.getText().toString().isEmpty()){
                    password.setError("Password is required");
                }
                else {
                    myDB.addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            flag = 0;
                            for(DataSnapshot ds : snapshot.getChildren()){
                                User user = ds.getValue(User.class);
                                if(user.email.equalsIgnoreCase(email.getText().toString()) && user.password.equals(password.getText().toString())){
                                    GlobalData.userName = user.email.substring(0, user.email.indexOf("@"));
                                    flag = 1;
                                    UserEmail = user.email;
                                    break;
                                }
                            }
                            if(flag == 1){
                                Toast.makeText(MainActivity.this, "Login successful", Toast.LENGTH_SHORT).show();
                                Intent i = new Intent(MainActivity.this, ProductsActivity.class);
                                startActivity(i);
                            }
                            else{
                                Toast.makeText(MainActivity.this, "Email or password is incorrect!", Toast.LENGTH_SHORT).show();
                            }
                            
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {

                        }
                    });
                }
            }
        });

        //Go to Registration Page
        newUser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MainActivity.this, RegistrationPage.class);
                startActivity(i);
            }
        });


    }
}