package com.example.onlinepharmacystore;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.Random;

public class MyProductOrder extends AppCompatActivity {
    TextView txt_productID, txt_productName, txt_productDescription, txt_productPrice, txt_productQuantity;
    Button backToMain;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_product_order);

        txt_productID = findViewById(R.id.textView28);
        txt_productName = findViewById(R.id.textView29);
        txt_productDescription = findViewById(R.id.textView30);
        txt_productPrice = findViewById(R.id.textView31);
        txt_productQuantity = findViewById(R.id.textView32);
        backToMain = findViewById(R.id.button5);



        Bundle bundle = getIntent().getExtras();
        txt_productID.setText(bundle.getString("productID"));
        txt_productName.setText(bundle.getString("productName"));
        txt_productDescription.setText(bundle.getString("productDescription"));
        txt_productPrice.setText(bundle.getString("productPrice"));
        txt_productQuantity.setText(bundle.getString("productQuantity"));

        backToMain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MyProductOrder.this, ProductsActivity.class);
                startActivity(i);
            }
        });

    }
}