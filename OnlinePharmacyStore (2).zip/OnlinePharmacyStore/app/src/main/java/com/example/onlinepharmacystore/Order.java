package com.example.onlinepharmacystore;

public class Order {
    public int OrderID, ProductID, RequiredQty;
    public String ProductName, UserName;
    public double Total,  ProductPrice;

    public Order() {
    }

    public Order(int orderID, int productID, int requiredQty, double productPrice, String productName, double total, String userName) {
        OrderID = orderID;
        ProductID = productID;
        RequiredQty = requiredQty;
        ProductPrice = productPrice;
        ProductName = productName;
        Total = total;
        UserName = userName;
    }
}
