package com.example.onlinepharmacystore;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class PaymentActivity extends AppCompatActivity {

    TextView amount;
    Button pay;
    EditText cardName, cardNumber, cardDate, cardCVV;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_payment);

        amount = findViewById(R.id.textView49);
        amount.setText(String.valueOf(GlobalData.totalPrice));

        pay = findViewById(R.id.button9);

        cardName = findViewById(R.id.editTextTextPersonName9);
        cardNumber = findViewById(R.id.editTextTextPersonName10);
        cardDate = findViewById(R.id.editTextTextPersonName11);
        cardCVV = findViewById(R.id.editTextTextPersonName13);

        pay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                GlobalData.paid = GlobalData.paid + GlobalData.totalPrice;
                if(cardName.getText().toString().isEmpty()){
                    cardName.setError("Enter your card name");
                }
                else if(cardNumber.getText().toString().isEmpty()){
                    cardNumber.setError("Enter your card number");
                }
                else if(cardNumber.getText().toString().length() != 16){
                    cardNumber.setError("Should be 16 digits");
                }
                else if(cardDate.getText().toString().isEmpty()){
                    cardDate.setError("Enter your card expiration date");
                }
                else if(cardCVV.getText().toString().isEmpty()){
                    cardCVV.setError("Enter your card CVV");
                }
                else if(cardCVV.getText().toString().length() != 3){
                    cardCVV.setError("Should be 3 digits");
                }
                else {
                    GlobalData.totalPrice = 0.0;
                    Toast.makeText(PaymentActivity.this, "Payment successfully, your order has been placed", Toast.LENGTH_SHORT).show();
                    Intent i = new Intent(PaymentActivity.this, BillsActivity.class);
                    startActivity(i);
                }

            }
        });
    }
}