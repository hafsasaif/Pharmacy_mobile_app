package com.example.onlinepharmacystore;

public class ProductInfo {
    public String productDescription, productName;
    public int productQuantity, productID;
    public double productPrice;

    public ProductInfo() {
    }

    public ProductInfo(String productDescription, String productName, int productQuantity, double productPrice, int productID) {
        this.productDescription = productDescription;
        this.productName = productName;
        this.productQuantity = productQuantity;
        this.productPrice = productPrice;
        this.productID = productID;
    }
}
