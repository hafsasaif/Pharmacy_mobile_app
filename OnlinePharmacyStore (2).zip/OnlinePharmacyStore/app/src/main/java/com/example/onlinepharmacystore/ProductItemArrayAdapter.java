package com.example.onlinepharmacystore;

import android.app.Activity;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.ArrayList;
import java.util.Random;

public class ProductItemArrayAdapter extends RecyclerView .Adapter<ProductItemArrayAdapter.ViewHolder> {

    public ArrayList<ProductInfo> itemArrayList;

    public ProductItemArrayAdapter(ArrayList<ProductInfo> itemArrayList){
        this.itemArrayList = itemArrayList;
    }


    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.product_item_layout, parent, false);
        ViewHolder viewHolder = new ViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        holder.txt_productID.setText(String.valueOf(itemArrayList.get(position).productID));
        holder.txt_productName.setText(itemArrayList.get(position).productName);
        holder.txt_productDescription.setText(itemArrayList.get(position).productDescription);
        holder.txt_productPrice.setText(String.valueOf(itemArrayList.get(position).productPrice));
        holder.txt_productQuantity.setText(String.valueOf(itemArrayList.get(position).productQuantity));
    }

    @Override
    public int getItemCount() {
        if(itemArrayList == null)
            return 0;
        else
            return itemArrayList.size();
    }

    class ViewHolder extends RecyclerView.ViewHolder {
        ImageView productImage;
        ImageView addImage, subImage;
        TextView txt_productID, txt_productName, txt_productDescription, txt_productPrice, txt_productQuantity, txt_qty;
        Button addToCart;
        int qty = 0;

        public int orderID, orderQty, availableQty;
        public double totalPrice;

        FirebaseDatabase fb;
        DatabaseReference myDB;

        public ViewHolder(@NonNull final View itemView) {
            super(itemView);
            productImage = itemView.findViewById(R.id.imageButton);

            txt_productID = itemView.findViewById(R.id.textView28);
            txt_productName = itemView.findViewById(R.id.textView29);
            txt_productDescription = itemView.findViewById(R.id.textView30);
            txt_productPrice = itemView.findViewById(R.id.textView31);
            txt_productQuantity = itemView.findViewById(R.id.textView32);

            addImage = itemView.findViewById(R.id.imageView3);
            subImage = itemView.findViewById(R.id.imageView2);
            txt_qty  = itemView.findViewById(R.id.textView24);
            addToCart = itemView.findViewById(R.id.button6);

            fb = FirebaseDatabase.getInstance();
            myDB = fb.getReference("orders");

            addImage.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    qty++;
                    txt_qty.setText(""+qty);
                }
            });

            subImage.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(Integer.parseInt(txt_qty.getText().toString()) != 0){
                        qty--;
                        txt_qty.setText(""+qty);
                    }
                }
            });

            addToCart.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    availableQty = Integer.parseInt(txt_productQuantity.getText().toString());
                    orderQty = Integer.parseInt(txt_qty.getText().toString());

                    if(Integer.parseInt(txt_qty.getText().toString()) == 0){
                        Toast.makeText(v.getContext(), "Please specify the quantity required", Toast.LENGTH_SHORT).show();
                    }
                    else if(orderQty > availableQty){
                        Toast.makeText(v.getContext(), "Sorry, this much quantity is not available", Toast.LENGTH_SHORT).show();
                    }
                    else {
                        Random random = new Random();
                        int randomNumber = random.nextInt(10000000);
                        orderID = Integer.parseInt(txt_productID.getText().toString()) + randomNumber;
                        totalPrice = Double.parseDouble(txt_productPrice.getText().toString()) * orderQty;
                        Order order = new Order(orderID, Integer.parseInt(txt_productID.getText().toString()), orderQty, Double.parseDouble(txt_productPrice.getText().toString()), txt_productName.getText().toString(), (double) Math.round(totalPrice*1000/1000), GlobalData.userName);
                        String key = myDB.push().getKey();
                        myDB.child(key).setValue(order);
                        Toast.makeText(v.getContext(), "Added to the cart", Toast.LENGTH_SHORT).show();
                    }
                    GlobalData.totalPrice = GlobalData.totalPrice + (double) Math.round(totalPrice*1000/1000);

                }
            });

            productImage.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent i = new Intent(v.getContext(), MyProductOrder.class);
                    i.putExtra("productID", txt_productID.getText().toString());
                    i.putExtra("productName", txt_productName.getText().toString());
                    i.putExtra("productDescription", txt_productDescription.getText().toString());
                    i.putExtra("productPrice", txt_productPrice.getText().toString());
                    i.putExtra("productQuantity", txt_productQuantity.getText().toString());
                    v.getContext().startActivity(i);
                }
            });


        }
    }

}
