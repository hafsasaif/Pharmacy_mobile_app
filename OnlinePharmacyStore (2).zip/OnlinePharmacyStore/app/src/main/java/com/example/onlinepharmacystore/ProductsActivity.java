package com.example.onlinepharmacystore;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;

public class ProductsActivity extends AppCompatActivity {

    RecyclerView data;
    ArrayList<ProductInfo> arrayList;
    ProductItemArrayAdapter productAdapter;

    FirebaseDatabase fb;
    DatabaseReference myDB;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_products);

        data = findViewById(R.id.recyclerView);
        arrayList = new ArrayList<ProductInfo>();



        fb = FirebaseDatabase.getInstance();
        myDB = fb.getReference("products");

        myDB.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for(DataSnapshot ds : snapshot.getChildren()){
                    ProductInfo productInfo = ds.getValue(ProductInfo.class);
                    arrayList.add(new ProductInfo(productInfo.productDescription, productInfo.productName, productInfo.productQuantity, productInfo.productPrice, productInfo.productID));
                }
                productAdapter.notifyDataSetChanged();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(this);
        data.setLayoutManager(linearLayoutManager);
        productAdapter = new ProductItemArrayAdapter(arrayList);
        data.setAdapter(productAdapter);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.my_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if(item.getItemId() == R.id.cart){
            Intent i = new Intent(ProductsActivity.this, CartActivity.class);
            startActivity(i);
        }
        if(item.getItemId() == R.id.bills){
            Intent i = new Intent(ProductsActivity.this, BillsActivity.class);
            startActivity(i);
        }
        if(item.getItemId() == R.id.logout){
            GlobalData.userName = "";
            GlobalData.totalPrice = 0.0;
            Toast.makeText(this, "Logged out", Toast.LENGTH_SHORT).show();
            Intent i = new Intent(ProductsActivity.this, WelcomePage.class);
            startActivity(i);
        }
        return super.onOptionsItemSelected(item);
    }
}