package com.example.onlinepharmacystore;

public class RatingInfo {
    public String userName, userRating;

    public RatingInfo() {
    }

    public RatingInfo(String userName, String userRating) {
        this.userName = userName;
        this.userRating = userRating;
    }
}
