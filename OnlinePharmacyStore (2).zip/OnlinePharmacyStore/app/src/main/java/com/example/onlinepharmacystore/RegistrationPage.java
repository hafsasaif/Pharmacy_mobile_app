package com.example.onlinepharmacystore;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class RegistrationPage extends AppCompatActivity {

    EditText firstName, lastName, email, password, passwordConfirm, phoneNumber;
    Button signUp, clear;
    RadioButton male, female;
    FirebaseDatabase fb;
    DatabaseReference myDB;
    CheckBox terms;
    int flag = 0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration_page);

        //Text View References
        firstName = findViewById(R.id.editTextTextPersonName);
        lastName = findViewById(R.id.editTextTextPersonName2);
        email = findViewById(R.id.editTextTextPersonName3);
        password = findViewById(R.id.editTextTextPersonName4);
        passwordConfirm = findViewById(R.id.editTextTextPersonName5);
        phoneNumber = findViewById(R.id.editTextTextPersonName6);

        //RadioButton References
        male = findViewById(R.id.radioButton);
        female = findViewById(R.id.radioButton2);

        //Button References
        signUp = findViewById(R.id.button);
        clear = findViewById(R.id.button2);

        //Checkbox
        terms = findViewById(R.id.checkBox);

        //Firebase
        fb = FirebaseDatabase.getInstance();
        myDB = fb.getReference("users");

        //Email Validation
        final String emailPattern = "[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+";

        //Clear Function
        clear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                firstName.setText("");
                lastName.setText("");
                male.setChecked(false);
                female.setChecked(false);
                email.setText("");
                password.setText("");
                passwordConfirm.setText("");
                phoneNumber.setText("");
            }
        });

        //Validations and save record
        signUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(firstName.getText().toString().isEmpty()){
                    firstName.setError("First name is required");
                }
                else if(lastName.getText().toString().isEmpty()){
                    lastName.setError("Last name is required");
                }
                else if(!male.isChecked() && !female.isChecked()){
                    Toast.makeText(RegistrationPage.this, "Please select your gender!", Toast.LENGTH_SHORT).show();
                }
                else if(email.getText().toString().isEmpty()){
                    email.setError("Email is required");
                }
                else if(!email.getText().toString().trim().matches(emailPattern)){
                    email.setError("Invalid email address");
                }
                else if(password.getText().toString().isEmpty()){
                    password.setError("Password is required");
                }
                else if(!password.getText().toString().equals(passwordConfirm.getText().toString())){
                    passwordConfirm.setError("Password and confirm password don't match");
                }
                else if(phoneNumber.getText().toString().isEmpty()){
                    phoneNumber.setError("Phone number is required");
                }
                else if(!phoneNumber.getText().toString().startsWith("9") && !phoneNumber.getText().toString().startsWith("7")){
                    phoneNumber.setError("Phone number should start with either 9 or 7");
                }
                else if(phoneNumber.getText().toString().length() != 8){
                    phoneNumber.setError("Phone number must be 8 digits only");
                }
                else if(!terms.isChecked()){
                    Toast.makeText(RegistrationPage.this, "Please check the terms and conditions box", Toast.LENGTH_SHORT).show();
                }
                else {
                    final String vFirstName, vLastName, vGender, vEmail, vPassword, vPhoneNumber;
                    vFirstName = firstName.getText().toString();
                    vLastName = lastName.getText().toString();
                    vGender = male.isChecked() ? "Male" : "Female";
                    vEmail = email.getText().toString().trim();
                    vPassword = password.getText().toString();
                    vPhoneNumber = phoneNumber.getText().toString();

                    myDB.addListenerForSingleValueEvent(new ValueEventListener() {
                        @Override
                        public void onDataChange(@NonNull DataSnapshot snapshot) {
                            flag = 0;
                            for(DataSnapshot ds : snapshot.getChildren()){
                                User user = ds.getValue(User.class);
                                if(user.email.equalsIgnoreCase(vEmail)){
                                    Toast.makeText(RegistrationPage.this, "This email address is already registered!", Toast.LENGTH_SHORT).show();
                                    flag = 1;
                                    break;
                                }
                            }
                            if(flag == 0){
                                User user = new User(vFirstName, vLastName, vGender, vEmail, vPassword, vPhoneNumber);
                                String key = myDB.push().getKey();
                                myDB.child(key).setValue(user);
                                Toast.makeText(RegistrationPage.this, "Registration successful, redirecting you to the login page", Toast.LENGTH_SHORT).show();
                                Intent i = new Intent(RegistrationPage.this, MainActivity.class);
                                startActivity(i);
                            }
                        }

                        @Override
                        public void onCancelled(@NonNull DatabaseError error) {

                        }
                    });
                }
            }
        });
    }
}