package com.example.onlinepharmacystore;

public class User {
    public String firstName, lastName, gender, email, password, phoneNumber;

    public User() {
    }

    public User(String firstName, String lastName, String gender, String email, String password, String phoneNumber) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.gender = gender;
        this.email = email;
        this.password = password;
        this.phoneNumber = phoneNumber;
    }
}
